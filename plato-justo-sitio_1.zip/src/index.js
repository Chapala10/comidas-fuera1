/**
 * Punto de entrada del Worker.
 *
 * Cloudflare revisa primero si la ruta pedida es un archivo estático (los que
 * están en /public: index.html, manifest, iconos) y lo sirve directo, sin
 * pasar por aquí. Solo las rutas que NO son un archivo, como /api/analizar,
 * llegan a este código. Por eso no hace falta enrutar nada más: si llegó
 * aquí y es /api/analizar, es la función de Gemini; cualquier otra cosa es
 * un 404 normal.
 */
import { manejar } from "./worker.js";

export default {
  fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/api/analizar") {
      return manejar(request, env);
    }
    return new Response("No encontrado", { status: 404 });
  }
};
